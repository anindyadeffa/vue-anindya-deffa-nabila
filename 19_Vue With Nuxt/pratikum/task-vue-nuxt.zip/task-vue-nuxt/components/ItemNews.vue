<template>
  <div class="item">
    <!-- <span class="score">2</span> -->
    <div>
        <div class="image">
          <img :src="news.urlToImage">
        </div>
        <div class="title">{{ news.title }}</div>
        <div class="author">{{ news.author }}</div>
        <div class="desc">{{ news.description }}</div>
    </div>
  </div>
</template>

<script>
  export default {
    props: {
      news: Object,
    }
  }
</script>
