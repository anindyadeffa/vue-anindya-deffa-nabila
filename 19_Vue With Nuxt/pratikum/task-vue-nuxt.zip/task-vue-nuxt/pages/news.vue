<template>
  <div>
    <h1>Berita Terkini</h1>
    <ItemNews
    v-for="(lists, index) in news"
    :key="index"
    :news="lists"
    />
  </div>
</template>

<script>
export default {
  layout: "default",
  mounted() {
    this.getNews();
  },
  computed: {
    news() {
      return this.$store.state.news.lists;
    }
  },
  methods: {
    getNews() {
      this.$store.dispatch("news/getNews");
    }
  }
}

</script>
