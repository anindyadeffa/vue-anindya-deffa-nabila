import createPersistedState from 'vuex-persistedstate'

export default ({ store }) => {
  createPersistedState({
    path: ["news"]
  })(store)
}
